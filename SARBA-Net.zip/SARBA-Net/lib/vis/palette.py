import os
import sys
import cv2
import numpy as np



def get_colors():
    color = np.array([(255,0,0), (0,0,0)], dtype = np.uint8)

    return color