# training command：
bash /****/SARBA_Net/scripts/sarbud/resnet38/run_wr_be_bc.sh train 250927
# test command：
bash /****/SARBA_Net/scripts/sarbud/resnet38/run_wr_be_bc.sh test_max 250927